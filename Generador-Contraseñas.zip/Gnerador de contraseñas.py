import secrets
import string

# Inicialización de variables
longitud_valida = False
opcion_valida = False
caracteres = ""

print("=== GENERADOR DE CONTRASEÑAS SEGURAS ===")

# Paso 1: Validar longitud con bucle while
while not longitud_valida:
    entrada = input("\nIngrese longitud de contraseña: ")
    
    try:
        longitud = int(entrada)
        
        # Validación con operador relacional
        if longitud < 8:
            print("ERROR: La contraseña debe tener mínimo 8 caracteres")
        else:
            longitud_valida = True
            
    except ValueError:
        print("ERROR: Por favor ingrese un número válido")

# Paso 2: Validar tipos de caracteres
while not opcion_valida:
    print("\nSeleccione los tipos de caracteres a incluir:")
    # Leer opciones
    mayus = input("¿Incluir mayúsculas? (s/n): ").lower() == 's'
    minus = input("¿Incluir minúsculas? (s/n): ").lower() == 's'
    numeros = input("¿Incluir números? (s/n): ").lower() == 's'
    simbolos = input("¿Incluir símbolos? (s/n): ").lower() == 's'
    
    # Verificar si al menos una opción fue seleccionada
    if mayus or minus or numeros or simbolos:
        opcion_valida = True
        
        # Construir conjunto de caracteres solo con las opciones seleccionadas
        if mayus: 
            caracteres += string.ascii_uppercase
            print(" Mayúsculas incluidas")
        if minus: 
            caracteres += string.ascii_lowercase
            print(" Minúsculas incluidas")
        if numeros: 
            caracteres += string.digits
            print(" Números incluidos")
        if simbolos: 
            caracteres += string.punctuation
            print(" Símbolos incluidos")
    else:
        print("\nERROR: Debe seleccionar al menos un tipo de carácter")

# Paso 3: Generar contraseña con bucle for
contraseña = ""
for i in range(longitud):
    # Selección segura de caracteres usando secrets
    caracter = secrets.choice(caracteres)
    contraseña += caracter

# Paso 4: Mostrar resultado
print("\n" + "="*50)
print("CONTRASEÑA GENERADA CON ÉXITO!")
print("="*50)
print(f"Longitud: {longitud} caracteres")
print(f"Contraseña: {contraseña}")
print("="*50)
print(" Esta contraseña es segura para uso personal")
print(" No la compartas con nadie")
print("="*50)